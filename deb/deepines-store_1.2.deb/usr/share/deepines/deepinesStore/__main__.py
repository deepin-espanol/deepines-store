#!/usr/bin/env python3
from deepinesStore.__init__ import main

main()