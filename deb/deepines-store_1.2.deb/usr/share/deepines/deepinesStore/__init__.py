#!/usr/bin/env python3
from deepinesStore.tienda import ejecutar
from deepinesStore.svg import ThreadingSvg

def main():
    ThreadingSvg()
    ejecutar()