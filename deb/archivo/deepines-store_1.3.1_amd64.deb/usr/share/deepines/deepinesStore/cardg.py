# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'guis/card.ui'
#
# Created by: PyQt5 UI code generator 5.13.0
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets



class QLabelClickable(QtWidgets.QLabel):

    clicked = QtCore.pyqtSignal()
    
    def __init__(self, *args):
        QtWidgets.QLabel.__init__(self, *args)
   
    def mouseReleaseEvent(self, ev):
        self.clicked.emit()



class Ui_Frame(object):
    def setupUi(self, Frame):
        Frame.setObjectName("Frame")
        Frame.resize(230, 249)
        Frame.setMinimumSize(QtCore.QSize(226, 249))
        Frame.setMaximumSize(QtCore.QSize(230, 16777215))
        self.verticalLayout = QtWidgets.QVBoxLayout(Frame)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setSpacing(0)
        self.verticalLayout.setObjectName("verticalLayout")
        self.image_app = QLabelClickable(Frame)
        self.image_app.setText("")
        self.image_app.setScaledContents(True)
        self.image_app.setAlignment(QtCore.Qt.AlignCenter)
        self.image_app.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.image_app.setObjectName("image_app")
        self.image_app.setStyleSheet("#image_app{margin-top: 10px;}")
        self.verticalLayout.addWidget(self.image_app)
        self.lbl_name_app = QLabelClickable(Frame)
        self.lbl_name_app.setStyleSheet("background-color: transparent;"
            "margin-top:5px;")
        self.lbl_name_app.setText("")
        self.lbl_name_app.setAlignment(QtCore.Qt.AlignCenter)
        self.lbl_name_app.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        font = QtGui.QFont()
        font.setFamily("Segoe UI Semibold")
        font.setPointSize(11)
        font.setItalic(False)
        self.lbl_name_app.setFont(font)
        self.lbl_name_app.setWordWrap(True)
        self.lbl_name_app.setObjectName("lbl_name_app")
        self.verticalLayout.addWidget(self.lbl_name_app)
        self.btn_select_app = QLabelClickable(Frame)
        font = QtGui.QFont()
        font.setFamily("Segoe UI Semibold")
        font.setPointSize(9)
        font.setItalic(False)
        self.btn_select_app.setFont(font)
        self.btn_select_app.setWordWrap(True)
        self.btn_select_app.setAlignment(QtCore.Qt.AlignCenter)
        self.btn_select_app.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.btn_select_app.setObjectName("btn_select_app")
        self.verticalLayout.addWidget(self.btn_select_app)

        self.retranslateUi(Frame)
        QtCore.QMetaObject.connectSlotsByName(Frame)

    def retranslateUi(self, Frame):
        _translate = QtCore.QCoreApplication.translate
        Frame.setWindowTitle(_translate("Frame", "Card"))
        self.btn_select_app.setText(_translate("Frame", "Instalar"))
